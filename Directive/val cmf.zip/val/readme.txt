Please put those files in validations folder of 2.8.2 taxonomy:
..\eiopa.europa.eu\eu\xbrl\s2md\fws\solvency\solvency2\2024-10-15\val